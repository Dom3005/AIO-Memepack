# AIO Memepack
This mods adds tons of german memes to the game!
## Features
- German meme sounds almost everywhere you go!
- New item (Jägermeister)
- QoL (fast dropship, brighter flashlight, infinite sprint, stronger shovel) (almost all can be disabled or changed inside the config, if desired)
- A free boombox spawns at the start of the round, if you dont have one already (can be disabled)
- Item scan shows you the value of all items in the ship
- Looking straight down/up
- Disable leave early vote (can be disabled in config)
- Instant Item delivery
- Skip boombox songs by pressing Q

## Future plans
- More items
- Custom enemies