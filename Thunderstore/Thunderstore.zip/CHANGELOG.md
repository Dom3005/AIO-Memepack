# 1.1
- Ship vote can be disabled
- Minor bugfixes
- Boombox songs can be skipped by pressing Q

# 1.2
- Fixed boombox out-of-sync issues, assuming all players use the same boombox songs (i recommend [AIO Boombox Songs mod](https://thunderstore.io/c/lethal-company/p/Dom3005/AIO_Boombox_Songs/))
- Boomboxes can be picked up in-flight now